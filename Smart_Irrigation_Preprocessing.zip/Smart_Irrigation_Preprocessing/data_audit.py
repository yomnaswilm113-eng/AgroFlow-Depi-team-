from pathlib import Path
import pandas as pd
import json

BASE_DIR = Path(__file__).resolve().parent
RAW_DIR = BASE_DIR / "data" / "raw"
AUDIT_DIR = BASE_DIR / "reports" / "data_quality" / "audit"

AUDIT_DIR.mkdir(parents=True, exist_ok=True)

FILES = [
    "irrigation_labels.csv",
    "smart irrigation dataset.xlsx",
    "weather_soil_delta.csv",
    "weather_soil_delta_multi.csv",
]


def load_file(path):
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)

    if path.suffix.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(path)

    raise ValueError(f"Unsupported file type: {path.suffix}")


def audit_dataset(file_name):
    path = RAW_DIR / file_name

    if not path.exists():
        print(f"FILE NOT FOUND: {file_name}")
        return

    print(f"\nAuditing: {file_name}")

    df = load_file(path)
    df.columns = df.columns.astype(str).str.strip()

    # Column-level audit
    columns_report = []

    for col in df.columns:
        series = df[col]

        missing_count = int(series.isna().sum())

        # Check whether a column that should be numeric
        # contains values that cannot be converted.
        numeric_check = pd.to_numeric(series, errors="coerce")

        non_numeric_count = int(
            (series.notna() & numeric_check.isna()).sum()
        )

        columns_report.append({
            "column": col,
            "dtype": str(series.dtype),
            "missing_count": missing_count,
            "missing_percentage": (
                round(missing_count / len(df) * 100, 2)
                if len(df) else 0
            ),
            "unique_count": int(series.nunique()),
            "non_numeric_values": non_numeric_count,
            "duplicate_column_name": (
                df.columns.tolist().count(col) > 1
            )
        })

    columns_report = pd.DataFrame(columns_report)

    # Exact duplicate rows
    duplicate_rows = df[df.duplicated(keep=False)].copy()

    # Datetime audit for recognized time columns
    datetime_report = []

    for col in df.columns:
        if col.lower() in ["time", "timestamp", "datetime", "date"]:
            parsed = pd.to_datetime(df[col], errors="coerce")

            invalid_count = int(
                (df[col].notna() & parsed.isna()).sum()
            )

            datetime_report.append({
                "column": col,
                "invalid_datetime_count": invalid_count,
                "valid_datetime_count": int(parsed.notna().sum())
            })

    # Save detailed reports
    safe_name = Path(file_name).stem

    columns_report.to_csv(
        AUDIT_DIR / f"{safe_name}_columns_audit.csv",
        index=False
    )

    duplicate_rows.to_csv(
        AUDIT_DIR / f"{safe_name}_duplicate_rows.csv",
        index=False
    )

    pd.DataFrame(datetime_report).to_csv(
        AUDIT_DIR / f"{safe_name}_datetime_audit.csv",
        index=False
    )

    summary = {
        "file": file_name,
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "missing_cells": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "datetime_checks": datetime_report,
        "status": "audited"
    }

    with open(
        AUDIT_DIR / f"{safe_name}_audit_summary.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(summary, f, indent=4, ensure_ascii=False)

    print("Rows:", df.shape[0])
    print("Columns:", df.shape[1])
    print("Missing cells:", df.isna().sum().sum())
    print("Duplicate rows:", df.duplicated().sum())
    print("Audit saved successfully.")


def main():
    print("=" * 50)
    print("DATA QUALITY AUDIT")
    print("=" * 50)

    for file_name in FILES:
        try:
            audit_dataset(file_name)
        except Exception as e:
            print(f"ERROR in {file_name}: {e}")

    print("\nAudit completed.")


if __name__ == "__main__":
    main()