from pathlib import Path
import logging
import numpy as np
import pandas as pd


# =========================================================
# 1. PROJECT PATHS
# =========================================================

BASE_DIR = Path(__file__).resolve().parent

RAW_DIR = BASE_DIR / "data" / "raw"
PROCESSED_DIR = BASE_DIR / "data" / "processed"
REPORT_DIR = BASE_DIR / "reports" / "data_cleaning"

PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)


# =========================================================
# 2. LOGGING
# =========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(
            REPORT_DIR / "cleaning.log",
            encoding="utf-8"
        ),
            logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


# =========================================================
# 3. SETTINGS
# =========================================================

SUPPORTED_EXTENSIONS = [".csv", ".xlsx", ".xls"]

DATETIME_NAMES = [
    "timestamp",
    "time",
    "datetime",
    "date",
    "date_time"
]

MISSING_TEXT_VALUES = [
    "",
    " ",
    "NA",
    "N/A",
    "na",
    "n/a",
    "null",
    "NULL",
    "None",
    "none",
    "-"
]


# =========================================================
# 4. LOAD DATA
# =========================================================

def load_dataset(file_path):

    if file_path.suffix.lower() == ".csv":

        df = pd.read_csv(file_path)

    elif file_path.suffix.lower() in [".xlsx", ".xls"]:

        df = pd.read_excel(file_path)

    else:

        raise ValueError(
            f"Unsupported file format: {file_path.suffix}"
        )

    return df


# =========================================================
# 5. CLEAN COLUMN NAMES
# =========================================================

def clean_column_names(df):

    df.columns = (
        df.columns
        .astype(str)
        .str.strip()
        .str.replace(r"\s+", "_", regex=True)
    )

    return df


# =========================================================
# 6. HANDLE MISSING VALUES
# =========================================================

def standardize_missing_values(df):

    # Replace common missing-value representations
    df = df.replace(
        MISSING_TEXT_VALUES,
        np.nan
    )

    # Remove surrounding spaces from text values
    for col in df.select_dtypes(
        include=["object", "string"]
    ).columns:

        df[col] = (
            df[col]
            .astype("string")
            .str.strip()
        )

        df[col] = df[col].replace(
            MISSING_TEXT_VALUES,
            np.nan
        )

    return df


def handle_missing_values(df):

    actions = []

    for col in df.columns:

        missing_count = df[col].isna().sum()

        if missing_count == 0:
            continue

        # Numeric columns: median imputation
        if pd.api.types.is_numeric_dtype(df[col]):

            median_value = df[col].median()

            if pd.notna(median_value):

                df[col] = df[col].fillna(
                    median_value
                )

                actions.append({
                    "column": col,
                    "missing_count": int(missing_count),
                    "method": "median imputation",
                    "replacement": median_value
                })

        # Categorical columns: mode imputation
        else:

            modes = df[col].mode(
                dropna=True
            )

            if not modes.empty:

                mode_value = modes.iloc[0]

                df[col] = df[col].fillna(
                    mode_value
                )

                actions.append({
                    "column": col,
                    "missing_count": int(missing_count),
                    "method": "mode imputation",
                    "replacement": mode_value
                })

    return df, actions


# =========================================================
# 7. HANDLE INCONSISTENT FORMATS
# =========================================================

def clean_text_formats(df):

    for col in df.select_dtypes(
        include=["object", "string"]
    ).columns:

        # Trim leading and trailing whitespace
        df[col] = (
            df[col]
            .astype("string")
            .str.strip()
        )

        # Standardize empty strings
        df[col] = df[col].replace(
            ["", " ", "nan", "NaN"],
            np.nan
        )

    return df


def convert_numeric_columns(df):

    converted_columns = []

    for col in df.columns:

        if not (
            pd.api.types.is_object_dtype(df[col])
            or pd.api.types.is_string_dtype(df[col])
        ):
            continue

        original = df[col]

        non_missing = original.dropna()

        if non_missing.empty:
            continue

        converted = pd.to_numeric(
            original,
            errors="coerce"
        )

        # Convert only if all existing values are numeric
        if converted[non_missing.index].notna().all():

            df[col] = converted

            converted_columns.append(col)

    return df, converted_columns


def convert_datetime_columns(df):

    converted_columns = []

    for col in df.columns:

        if col.lower().strip() not in DATETIME_NAMES:
            continue

        converted = pd.to_datetime(
            df[col],
            errors="coerce",
            format="mixed"
        )

        df[col] = converted

        converted_columns.append(col)

    return df, converted_columns


# =========================================================
# 8. HANDLE INVALID NUMERIC VALUES
# =========================================================

def handle_invalid_numeric_values(df):

    numeric_columns = df.select_dtypes(
        include=[np.number]
    ).columns

    invalid_report = []

    for col in numeric_columns:

        invalid_mask = (
            df[col].isin([np.inf, -np.inf])
        )

        invalid_count = int(
            invalid_mask.sum()
        )

        if invalid_count > 0:

            df.loc[invalid_mask, col] = np.nan

            invalid_report.append({
                "column": col,
                "invalid_count": invalid_count,
                "action": "infinity replaced with missing value"
            })

    # After converting infinity to NaN,
    # fill numeric missing values with median
    for col in numeric_columns:

        median_value = df[col].median()

        if pd.notna(median_value):

            df[col] = df[col].fillna(
                median_value
            )

    return df, invalid_report


# =========================================================
# 9. HANDLE DUPLICATE RECORDS
# =========================================================

def remove_duplicates(df):

    before = len(df)

    df = df.drop_duplicates().copy()

    removed_count = before - len(df)

    return df, removed_count


# =========================================================
# 10. CLEANING REPORT
# =========================================================

def save_cleaning_report(
    file_name,
    original_shape,
    cleaned_shape,
    duplicate_count,
    missing_actions,
    numeric_conversions,
    datetime_conversions,
    invalid_report
):

    report = {
        "file": file_name,
        "original_rows": original_shape[0],
        "original_columns": original_shape[1],
        "cleaned_rows": cleaned_shape[0],
        "cleaned_columns": cleaned_shape[1],
        "duplicates_removed": duplicate_count,
        "missing_value_actions": missing_actions,
        "numeric_columns_converted": numeric_conversions,
        "datetime_columns_converted": datetime_conversions,
        "invalid_numeric_values": invalid_report
    }

    report_path = (
        REPORT_DIR
        / f"{Path(file_name).stem}_cleaning_report.json"
    )

    import json

    with open(
        report_path,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            report,
            file,
            indent=4,
            ensure_ascii=False,
            default=str
        )


# =========================================================
# 11. CLEAN ONE DATASET
# =========================================================

def clean_dataset(file_path):

    logger.info("=" * 50)
    logger.info("Cleaning: %s", file_path.name)

    df = load_dataset(file_path)

    original_shape = df.shape

    # Clean column names
    df = clean_column_names(df)

    # Standardize missing values
    df = standardize_missing_values(df)

    # Standardize text formats
    df = clean_text_formats(df)

    # Convert numeric columns
    df, numeric_conversions = (
        convert_numeric_columns(df)
    )

    # Convert datetime columns
    df, datetime_conversions = (
        convert_datetime_columns(df)
    )

    # Replace invalid infinite numeric values
    df, invalid_report = (
        handle_invalid_numeric_values(df)
    )

    # Remove exact duplicate rows
    df, duplicate_count = remove_duplicates(df)

    # Handle missing values
    df, missing_actions = (
        handle_missing_values(df)
    )

    cleaned_shape = df.shape

    # Save cleaned dataset as CSV
    output_file = (
        PROCESSED_DIR
        / f"{file_path.stem}_clean.csv"
    )

    df.to_csv(
        output_file,
        index=False
    )

    # Save cleaning report
    save_cleaning_report(
        file_path.name,
        original_shape,
        cleaned_shape,
        duplicate_count,
        missing_actions,
        numeric_conversions,
        datetime_conversions,
        invalid_report
    )

    logger.info(
        "Finished: %s",
        file_path.name
    )

    logger.info(
        "Original shape: %s | Cleaned shape: %s",
        original_shape,
        cleaned_shape
    )

    logger.info(
        "Duplicates removed: %d",
        duplicate_count
    )

    logger.info(
        "Saved to: %s",
        output_file
    )

    return {
        "file": file_path.name,
        "status": "success",
        "original_rows": original_shape[0],
        "cleaned_rows": cleaned_shape[0],
        "duplicates_removed": duplicate_count,
        "output": output_file.name
    }


# =========================================================
# 12. MAIN
# =========================================================

def main():

    logger.info("Starting Data Cleaning Pipeline")

    files = [
        file for file in RAW_DIR.iterdir()
        if file.is_file()
        and file.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not files:

        logger.error(
            "No supported datasets found in raw folder."
        )

        return

    results = []

    for file_path in sorted(files):

        try:

            result = clean_dataset(
                file_path
            )

            results.append(result)

        except Exception as error:

            logger.exception(
                "Error cleaning %s",
                file_path.name
            )

            results.append({
                "file": file_path.name,
                "status": "failed",
                "error": str(error)
            })

    # Save overall summary
    summary = pd.DataFrame(results)

    summary.to_csv(
        REPORT_DIR
        / "cleaning_summary.csv",
        index=False
    )

    print("\n" + "=" * 50)
    print("DATA CLEANING SUMMARY")
    print("=" * 50)

    print(
        summary.to_string(
            index=False
        )
    )

    logger.info("Data Cleaning Pipeline Completed")


if __name__ == "__main__":
    main()